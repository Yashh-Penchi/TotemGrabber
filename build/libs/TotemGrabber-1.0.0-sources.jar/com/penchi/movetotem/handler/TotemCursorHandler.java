package com.penchi.movetotem.handler;

import com.penchi.movetotem.config.ModConfig;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_310;
import net.minecraft.class_490;
import java.lang.reflect.Method;
import java.util.List;

public class TotemCursorHandler {

    public static void register() {
        ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
            if (!(screen instanceof class_490 invScreen)) return;
            scheduleJump(client, invScreen);
        });
    }

    private static void scheduleJump(class_310 client, class_490 invScreen) {
        if (!ModConfig.get().enabled) return;

        int delayMs = ModConfig.get().delayMs;

        Thread t = new Thread(() -> {
            try {
                Thread.sleep(delayMs);
            } catch (InterruptedException ignored) {}

            client.execute(() -> {
                if (client.field_1755 != invScreen) return;
                if (client.field_1724 == null) return;

                // Agar offhand mein totem ya shield hai — vanilla behaviour, koi jump nahi
                class_1799 offhand = client.field_1724.method_6079();
                if (offhand.method_31574(class_1802.field_8288) || offhand.method_31574(class_1802.field_8255)) return;

                class_1735 target = findTargetSlot(client, invScreen);
                if (target == null) return;

                moveCursorToSlot(client, invScreen, target);
            });
        });
        t.setDaemon(true);
        t.start();
    }

    private static class_1735 findTargetSlot(class_310 client, class_490 invScreen) {
        List<class_1735> slots = invScreen.method_17577().field_7761;

        class_1735 firstInvTotem    = null;
        class_1735 firstHotbarTotem = null;
        class_1735 firstInvShield   = null;

        for (class_1735 slot : slots) {
            class_1799 stack = slot.method_7677();
            if (stack.method_7960()) continue;

            int invIndex = slot.method_34266();
            if (invIndex >= 36) continue;

            boolean isHotbar = (invIndex <= 8);

            if (stack.method_31574(class_1802.field_8288)) {
                if (!isHotbar && firstInvTotem == null)        firstInvTotem = slot;
                else if (isHotbar && firstHotbarTotem == null) firstHotbarTotem = slot;
            }
            if (stack.method_31574(class_1802.field_8255)) {
                if (!isHotbar && firstInvShield == null)       firstInvShield = slot;
            }
        }

        if (firstInvTotem != null)    return firstInvTotem;
        if (firstHotbarTotem != null) return firstHotbarTotem;
        if (firstInvShield != null)   return firstInvShield;
        return null;
    }

    private static void moveCursorToSlot(class_310 client, class_490 invScreen, class_1735 slot) {
        try {
            int screenWidth  = client.method_22683().method_4486();
            int screenHeight = client.method_22683().method_4502();

            int bgWidth  = 176;
            int bgHeight = 166;
            int originX  = (screenWidth  - bgWidth)  / 2;
            int originY  = (screenHeight - bgHeight) / 2;

            int invIndex = slot.method_34266();
            int slotX, slotY;

            if (invIndex >= 9 && invIndex <= 35) {
                int col = (invIndex - 9) % 9;
                int row = (invIndex - 9) / 9;
                slotX = originX + 8  + col * 18 + 8;
                slotY = originY + 84 + row * 18 + 8;
            } else if (invIndex <= 8) {
                slotX = originX + 8 + invIndex * 18 + 8;
                slotY = originY + 142 + 8;
            } else {
                return;
            }

            double scale  = client.method_22683().method_4495();
            double pixelX = slotX * scale;
            double pixelY = slotY * scale;

            long windowHandle = client.method_22683().method_4490();
            org.lwjgl.glfw.GLFW.glfwSetCursorPos(windowHandle, pixelX, pixelY);

            Method m = findMethod(client.field_1729.getClass(), "onCursorPos", long.class, double.class, double.class);
            if (m != null) {
                m.setAccessible(true);
                m.invoke(client.field_1729, windowHandle, pixelX, pixelY);
            }

        } catch (Exception e) {
            // silent
        }
    }

    // ── Shift+Click listener — totem on hovered slot → offhand (only if offhand empty) ──
    public static boolean handleShiftClick(class_310 client, class_1735 hoveredSlot) {
        if (!ModConfig.get().enabled) return false;
        if (client.field_1724 == null) return false;

        // Sirf tab kaam kare jab offhand bilkul empty ho
        class_1799 offhand = client.field_1724.method_6079();
        if (!offhand.method_7960()) return false;

        // Hovered slot mein totem hona chahiye
        if (hoveredSlot == null) return false;
        if (!hoveredSlot.method_7677().method_31574(class_1802.field_8288)) return false;

        // Offhand slot index vanilla inventory screen mein = 45
        int offhandSlotIndex = 45;

        // Swap: pick up from hovered slot, place in offhand using slot swap (button 40 = offhand swap)
        // SlotActionType.SWAP with button=40 swaps hovered slot with offhand
        client.field_1761.method_2906(
                client.field_1724.field_7512.field_7763,
                hoveredSlot.field_7874,
                40, // 40 = offhand slot button
                class_1713.field_7791,
                client.field_1724
        );

        return true; // event consumed — vanilla shift click cancel
    }

    private static Method findMethod(Class<?> cls, String name, Class<?>... params) {
        while (cls != null) {
            try {
                return cls.getDeclaredMethod(name, params);
            } catch (NoSuchMethodException ignored) {
                cls = cls.getSuperclass();
            }
        }
        return null;
    }
}