package com.penchi.movetotem.mixin;

import com.penchi.movetotem.handler.TotemCursorHandler;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_310;
import net.minecraft.class_465;
import net.minecraft.class_490;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_465.class)
public class InventoryScreenMixin {

    @Inject(method = "onMouseClick(Lnet/minecraft/screen/slot/Slot;IILnet/minecraft/screen/slot/SlotActionType;)V",
            at = @At("HEAD"), cancellable = true)
    private void onSlotClick(class_1735 slot, int slotId, int button, class_1713 actionType, CallbackInfo ci) {
        // Sirf InventoryScreen pe fire karo
        class_310 client = class_310.method_1551();
        if (!(client.field_1755 instanceof class_490)) return;

        // Sirf shift+click intercept karo (actionType = QUICK_MOVE, button = 0)
        if (actionType != class_1713.field_7794) return;

        boolean consumed = TotemCursorHandler.handleShiftClick(client, slot);
        if (consumed) ci.cancel(); // vanilla shift click rok do
    }
}